# USM Hockey > 2023-12-15 1:57am
https://universe.roboflow.com/cos-475/usm-hockey

Provided by a Roboflow user
License: CC BY 4.0

